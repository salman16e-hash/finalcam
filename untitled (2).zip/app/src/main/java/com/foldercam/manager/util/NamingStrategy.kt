package com.foldercam.manager.util

import java.text.SimpleDateFormat
import java.util.*

object NamingStrategy {
    fun generateDefaultName(prefix: String = "IMG"): String {
        return prefix + "_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
    }
}
