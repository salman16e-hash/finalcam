package com.foldercam.manager.util

import android.content.Context
import android.media.MediaScannerConnection
import java.io.File

object CameraSaveHelper {
    fun scanFile(context: Context, file: File) {
        MediaScannerConnection.scanFile(
            context,
            arrayOf(file.absolutePath),
            arrayOf("image/jpeg"),
            null
        )
    }
}
