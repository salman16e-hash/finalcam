package com.foldercam.manager.util

import com.foldercam.manager.model.FileItem

interface FileManager {
    suspend fun listFiles(path: String): List<FileItem>
    suspend fun delete(path: String): Boolean
    suspend fun rename(path: String, newName: String): Boolean
    suspend fun createFolder(parentPath: String, name: String): Boolean
}
