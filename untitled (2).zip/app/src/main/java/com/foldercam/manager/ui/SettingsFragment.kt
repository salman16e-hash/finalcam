package com.foldercam.manager.ui

import android.os.Bundle
import androidx.preference.PreferenceFragmentCompat
import com.foldercam.manager.R

class SettingsFragment : PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.root_preferences, rootKey)
    }
}
