package com.foldercam.manager.adapter

import androidx.recyclerview.widget.DiffUtil
import com.foldercam.manager.model.FileItem

class FileItemDiffCallback : DiffUtil.ItemCallback<FileItem>() {
    override fun areItemsTheSame(oldItem: FileItem, newItem: FileItem): Boolean {
        return oldItem.path == newItem.path
    }

    override fun areContentsTheSame(oldItem: FileItem, newItem: FileItem): Boolean {
        return oldItem == newItem
    }
}
