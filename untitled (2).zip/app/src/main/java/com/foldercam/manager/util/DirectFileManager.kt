package com.foldercam.manager.util

import com.foldercam.manager.model.FileItem
import java.io.File

class DirectFileManager : FileManager {

    override suspend fun listFiles(path: String): List<FileItem> {
        val root = File(path)
        val files = root.listFiles() ?: return emptyList()
        
        return files.map {
            FileItem(
                name = it.name,
                path = it.absolutePath,
                isDirectory = it.isDirectory,
                size = if (it.isDirectory) 0 else it.length(),
                lastModified = it.lastModified(),
                extension = it.extension
            )
        }
    }

    override suspend fun delete(path: String): Boolean {
        return File(path).deleteRecursively()
    }

    override suspend fun rename(path: String, newName: String): Boolean {
        val oldFile = File(path)
        val newFile = File(oldFile.parentFile, newName)
        return oldFile.renameTo(newFile)
    }

    override suspend fun createFolder(parentPath: String, name: String): Boolean {
        val newFolder = File(parentPath, name)
        return newFolder.mkdirs()
    }
}
