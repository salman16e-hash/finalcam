package com.foldercam.manager.ui

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.GridLayoutManager
import com.foldercam.manager.R
import com.foldercam.manager.adapter.FileAdapter
import com.foldercam.manager.databinding.BottomSheetFileActionsBinding
import com.foldercam.manager.databinding.DialogConfirmDeleteBinding
import com.foldercam.manager.databinding.DialogCreateFolderBinding
import com.foldercam.manager.databinding.DialogRenameFileBinding
import com.foldercam.manager.databinding.DialogRenameJpegBinding
import com.foldercam.manager.databinding.FragmentFileBrowserBinding
import com.foldercam.manager.model.FileItem
import com.foldercam.manager.model.SortMode
import com.foldercam.manager.model.ViewMode
import com.foldercam.manager.viewmodel.FileViewModel
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import java.io.File

class FileBrowserFragment : Fragment() {

    private var _binding: FragmentFileBrowserBinding? = null
    private val binding get() = _binding!!
    private val viewModel: FileViewModel by viewModels()
    private val args: FileBrowserFragmentArgs by navArgs()
    
    private lateinit var adapter: FileAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFileBrowserBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupToolbar()
        setupRecyclerView()
        setupObvservers()
        setupSearch()
        setupFab()
    }

    override fun onResume() {
        super.onResume()
        checkStoragePermission()
    }

    private fun checkStoragePermission() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            if (!android.os.Environment.isExternalStorageManager()) {
                AlertDialog.Builder(requireContext())
                    .setTitle("Permission Required")
                    .setMessage("FolderCam needs 'All Files Access' to manage your folders and save photos directly where you want them.")
                    .setPositiveButton("Grant") { _, _ ->
                        try {
                            val intent = android.content.Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                            startActivity(intent)
                        } catch (e: Exception) {
                            val intent = android.content.Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                            intent.data = android.net.Uri.parse("package:${requireContext().packageName}")
                            startActivity(intent)
                        }
                    }
                    .setNegativeButton("Exit") { _, _ -> activity?.finish() }
                    .setCancelable(false)
                    .show()
            } else {
                onPermissionGranted()
            }
        } else {
            if (androidx.core.content.ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 1001)
            } else {
                onPermissionGranted()
            }
        }
    }

    private fun onPermissionGranted() {
        if (args.currentPath != "root") {
            viewModel.setPath(args.currentPath)
        } else {
            viewModel.refreshFiles()
        }
    }

    private fun setupToolbar() {
        binding.toolbar.title = File(viewModel.currentPath.value ?: "").name.ifEmpty { "Internal Storage" }
        
        if (args.currentPath != "root") {
            binding.toolbar.setNavigationIcon(R.drawable.ic_back)
            binding.toolbar.setNavigationOnClickListener { findNavController().navigateUp() }
        }

        binding.toolbar.inflateMenu(R.menu.menu_browser)
        binding.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_view_mode -> {
                    val current = viewModel.viewMode.value ?: ViewMode.LIST
                    val next = if (current == ViewMode.LIST) {
                        item.setIcon(R.drawable.ic_list)
                        ViewMode.GRID
                    } else {
                        item.setIcon(R.drawable.ic_grid)
                        ViewMode.LIST
                    }
                    viewModel.setViewMode(next)
                    true
                }
                R.id.action_add_folder -> {
                    showCreateFolderDialog()
                    true
                }
                R.id.action_sort -> {
                    showSortMenu()
                    true
                }
                R.id.action_settings -> {
                    findNavController().navigate(R.id.action_fileBrowserFragment_to_settingsFragment)
                    true
                }
                else -> false
            }
        }
    }

    private fun setupRecyclerView() {
        adapter = FileAdapter(
            onItemClick = { file ->
                if (file.isDirectory) {
                    val action = FileBrowserFragmentDirections.actionFileBrowserFragmentSelf(file.path)
                    findNavController().navigate(action)
                } else if (file.extension.lowercase() in listOf("jpg", "jpeg", "png", "gif", "webp")) {
                    val action = FileBrowserFragmentDirections.actionFileBrowserFragmentToImagePreviewFragment(file.path)
                    findNavController().navigate(action)
                }
            },
            onItemLongClick = { file ->
                showFileActions(file)
            }
        )
        
        binding.recyclerView.adapter = adapter
        
        viewModel.viewMode.observe(viewLifecycleOwner) { mode ->
            val columns = if (mode == ViewMode.GRID) 3 else 1
            binding.recyclerView.layoutManager = GridLayoutManager(context, columns)
            adapter.setViewMode(mode)
        }
    }

    private fun setupObvservers() {
        viewModel.files.observe(viewLifecycleOwner) { files ->
            adapter.submitList(files)
        }
        
        viewModel.currentPath.observe(viewLifecycleOwner) { path ->
            binding.toolbar.title = File(path).name.ifEmpty { "Internal Storage" }
        }
    }

    private fun setupSearch() {
        binding.searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.setSearchQuery(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun setupFab() {
        binding.fabCamera.setOnClickListener {
            val path = viewModel.currentPath.value ?: return@setOnClickListener
            val action = FileBrowserFragmentDirections.actionFileBrowserFragmentToCameraFragment(path)
            findNavController().navigate(action)
        }
    }

    private fun showCreateFolderDialog() {
        val dialogBinding = DialogCreateFolderBinding.inflate(layoutInflater)
        AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.save) { _, _ ->
                val name = dialogBinding.editFolderName.text.toString()
                if (name.isNotEmpty()) {
                    viewModel.createFolder(name) { success, error ->
                        if (!success) {
                            Snackbar.make(binding.root, error ?: "Error", Snackbar.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showSortMenu() {
        val modes = SortMode.values()
        val names = modes.map { it.name.replace("_", " ").lowercase().capitalize() }.toTypedArray()
        
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.sort)
            .setItems(names) { _, which ->
                viewModel.setSortMode(modes[which])
            }
            .show()
    }

    private fun showFileActions(file: FileItem) {
        val bottomSheet = BottomSheetDialog(requireContext())
        val dialogBinding = BottomSheetFileActionsBinding.inflate(layoutInflater)
        bottomSheet.setContentView(dialogBinding.root)
        
        dialogBinding.txtSelectedFileName.text = file.name
        
        dialogBinding.btnRename.setOnClickListener {
            bottomSheet.dismiss()
            showRenameDialog(file)
        }
        
        dialogBinding.btnDelete.setOnClickListener {
            bottomSheet.dismiss()
            showDeleteConfirmDialog(file)
        }
        
        dialogBinding.btnShare.setOnClickListener {
            bottomSheet.dismiss()
            shareFile(file)
        }

        dialogBinding.btnDetails.setOnClickListener {
            bottomSheet.dismiss()
            showDetailsDialog(file)
        }

        bottomSheet.show()
    }

    private fun shareFile(fileItem: FileItem) {
        try {
            val file = File(fileItem.path)
            val uri = androidx.core.content.FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", file)
            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = if (fileItem.isDirectory) "application/zip" else android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension) ?: "*/*"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(android.content.Intent.createChooser(intent, "Share via"))
        } catch (e: Exception) {
            Snackbar.make(binding.root, "Cannot share this file", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun showDetailsDialog(file: FileItem) {
        val details = """
            Name: ${file.name}
            Path: ${file.path}
            Size: ${if (file.isDirectory) "--" else FileSizeFormatter.formatSize(file.size)}
            Modified: ${java.text.SimpleDateFormat("dd MMM yyyy, HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(file.lastModified))}
        """.trimIndent()
        
        AlertDialog.Builder(requireContext())
            .setTitle("File Details")
            .setMessage(details)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showRenameDialog(file: FileItem) {
        val dialogBinding = DialogRenameFileBinding.inflate(layoutInflater)
        dialogBinding.editFileName.setText(file.name)
        
        AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.rename) { _, _ ->
                val newName = dialogBinding.editFileName.text.toString()
                if (newName.isNotEmpty() && newName != file.name) {
                    viewModel.renameFile(file, newName) { success ->
                        if (!success) Snackbar.make(binding.root, "Rename failed", Snackbar.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showDeleteConfirmDialog(file: FileItem) {
        val dialogBinding = DialogConfirmDeleteBinding.inflate(layoutInflater)
        AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.delete) { _, _ ->
                viewModel.deleteFile(file) { success ->
                    if (!success) Snackbar.make(binding.root, "Delete failed", Snackbar.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
