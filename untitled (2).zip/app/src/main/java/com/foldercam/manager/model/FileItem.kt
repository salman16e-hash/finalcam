package com.foldercam.manager.model

import java.io.File

data class FileItem(
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val size: Long,
    val lastModified: Long,
    val extension: String = "",
    var isSelected: Boolean = false
) {
    fun toFile(): File = File(path)
}
